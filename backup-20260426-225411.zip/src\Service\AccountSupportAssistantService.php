<?php

namespace App\Service;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class AccountSupportAssistantService
{
    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly string $groqApiKey = '',
    ) {
    }

    /**
     * @return array{resolved: bool, answer: string}
     */
    public function answerQuestion(string $question, string $locale, array $history = []): array
    {
        $question = $this->cleanText($question);
        $locale = $this->normalizeLocale($locale);
        $history = $this->sanitizeHistory($history);

        if ($question === '' || mb_strlen($question) < 3) {
            throw new \InvalidArgumentException('Please describe the problem in a short sentence.');
        }

        if ($this->groqApiKey !== '') {
            try {
                $response = $this->httpClient->request('POST', 'https://api.groq.com/openai/v1/chat/completions', [
                    'headers' => [
                        'Authorization' => 'Bearer '.$this->groqApiKey,
                        'Content-Type' => 'application/json',
                    ],
                    'timeout' => 20,
                    'json' => [
                        'model' => 'llama3-8b-8192',
                        'temperature' => 0.2,
                        'messages' => [
                            [
                                'role' => 'system',
                                'content' => 'You are a concise account-access support assistant for a web app. You help users who cannot sign in due to blocked/deactivated accounts or related login issues. Use conversation context when provided. Do not invent internal policy. If user action likely fixes it (email typo/password reset), set resolved=true. If admin review is needed, set resolved=false and tell them to request admin intervention. Keep replies to 2-4 short sentences. Return valid JSON only with keys resolved and answer.',
                            ],
                            [
                                'role' => 'user',
                                'content' => $this->buildPrompt($locale, $question, $history),
                            ],
                        ],
                    ],
                ]);

                $payload = $response->toArray(false);
                $content = (string) ($payload['choices'][0]['message']['content'] ?? '');
                $decoded = $this->decodeAssistantResponse($content);
                if ($decoded !== null) {
                    return $decoded;
                }
            } catch (ExceptionInterface|\Throwable) {
            }
        }

        return $this->buildFallbackResponse($question, $locale);
    }

    /**
     * @param array<int, array{role: string, content: string}> $history
     */
    private function buildPrompt(string $locale, string $question, array $history): string
    {
        $historyLines = [];
        foreach ($history as $entry) {
            $historyLines[] = sprintf('%s: %s', $entry['role'], $entry['content']);
        }

        $historyBlock = $historyLines === [] ? 'No previous conversation.' : implode("\n", $historyLines);

        return sprintf(
            "Locale: %s\nConversation so far:\n%s\n\nCurrent user message: %s\n\nReturn JSON only with exact shape: {\"resolved\":true|false,\"answer\":\"...\"}",
            $locale,
            $historyBlock,
            $question
        );
    }

    /**
     * @return array{resolved: bool, answer: string}|null
     */
    private function decodeAssistantResponse(string $content): ?array
    {
        $content = trim($content);
        if ($content === '') {
            return null;
        }

        if (str_starts_with($content, '```')) {
            $content = preg_replace('/^```(?:json)?\s*|\s*```$/', '', $content) ?? $content;
        }

        $decoded = json_decode(trim($content), true);
        if (!is_array($decoded) || !array_key_exists('resolved', $decoded) || !array_key_exists('answer', $decoded)) {
            return null;
        }

        $answer = $this->cleanText((string) $decoded['answer']);
        if ($answer === '') {
            return null;
        }

        return [
            'resolved' => (bool) $decoded['resolved'],
            'answer' => $this->limitText($answer, 500),
        ];
    }

    /**
     * @return array{resolved: bool, answer: string}
     */
    private function buildFallbackResponse(string $question, string $locale): array
    {
        $q = mb_strtolower($question);

        if (str_contains($q, 'why') && (str_contains($q, 'blocked') || str_contains($q, 'deactivated'))) {
            return [
                'resolved' => false,
                'answer' => $locale === 'fr'
                    ? 'Je ne peux pas voir la raison interne exacte du blocage depuis ce chat. Je peux vous aider a verifier email et mot de passe, puis vous pouvez demander l intervention admin pour une verification officielle.'
                    : 'I cannot see the internal exact reason for the block from this chat. I can help verify your email/password steps, then you can request admin intervention for an official review.',
            ];
        }

        if (str_contains($q, 'wrong password') || str_contains($q, 'mot de passe')) {
            return [
                'resolved' => true,
                'answer' => $locale === 'fr'
                    ? 'Essayez d abord la reinitialisation du mot de passe depuis la page de connexion. Si le compte reste bloque apres cela, envoyez une demande d intervention admin ci-dessous.'
                    : 'First try password reset from the login page. If your account is still blocked after that, send an admin intervention request below.',
            ];
        }

        if (str_contains($q, 'email') || str_contains($q, 'mail')) {
            return [
                'resolved' => true,
                'answer' => $locale === 'fr'
                    ? 'Verifiez que vous utilisez le meme email que lors de l inscription, sans espace. Ensuite reessayez la connexion.'
                    : 'Confirm you are using the exact registration email with no extra spaces, then try logging in again.',
            ];
        }

        return [
            'resolved' => false,
            'answer' => $locale === 'fr'
                ? 'Je n ai pas assez d informations pour corriger cela automatiquement. Utilisez le bouton d intervention admin et decrivez ce qui se passe; un administrateur vous repondra.'
                : 'I do not have enough information to fix this automatically. Use the admin intervention button and describe what is happening; an admin will follow up.',
        ];
    }

    private function normalizeLocale(string $locale): string
    {
        return str_starts_with(strtolower($locale), 'fr') ? 'fr' : 'en';
    }

    /**
     * @param array<mixed> $history
     * @return array<int, array{role: string, content: string}>
     */
    private function sanitizeHistory(array $history): array
    {
        $sanitized = [];

        foreach ($history as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $role = isset($entry['role']) ? strtolower(trim((string) $entry['role'])) : 'user';
            if (!in_array($role, ['user', 'assistant'], true)) {
                $role = 'user';
            }

            $content = $this->cleanText((string) ($entry['content'] ?? ''));
            if ($content === '') {
                continue;
            }

            $sanitized[] = [
                'role' => $role,
                'content' => $this->limitText($content, 360),
            ];

            if (count($sanitized) >= 12) {
                break;
            }
        }

        return $sanitized;
    }

    private function cleanText(string $value): string
    {
        return trim((string) preg_replace('/\s+/', ' ', $value));
    }

    private function limitText(string $value, int $length): string
    {
        if (mb_strlen($value) <= $length) {
            return $value;
        }

        return rtrim(mb_substr($value, 0, max(0, $length - 3))).'...';
    }
}
